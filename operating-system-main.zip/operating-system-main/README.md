# operating-system
operating system programs and algorithms in c 
First in First Serve Scheduling
 Shortest Job First Scheduling
 Round Robin Scheduling
 Priority Scheduling
 Shortest Remaining Time First
 First in First Out Page Replacement
 Least Recently Used
 Optimal Page Replacement
 System calls
 Memory Management
